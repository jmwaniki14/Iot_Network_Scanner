from scapy.all import *
from scapy.layers.dot11 import Dot11, Dot11Deauth
import threading
import smtplib
from email.mime.text import MIMEText

# Set the network interface you want to monitor
interface = 'Wi-Fi'

# Set packet counter
packet_counter = 1

# Flag to track if deauthentication packet is detected
deauth_detected = False

# Extract information from the packet
def info(packet):
    global packet_counter
    global deauth_detected
    
    if packet.haslayer(Dot11):
        if packet.type == 0 and packet.subtype == 12:  # Deauthentication frame
            print(f"[+] Deauthentication Packet detected! Count: {packet_counter}")
            packet_counter += 1
            deauth_detected = True
        elif packet.type == 0 and packet.subtype == 8:  # Management frame
            print("Management Frame detected.")
    else:
        print("Non-Dot11 packet detected.")

# Define function to send email
def send_email(subject, message):
    sender_email = "justus@spa-limited.com"  # Replace with your work email address
    receiver_email = "jmwaniki14@gmail.com"  # Replace with the recipient's email address
    password = "Tumbleweed@14"  # Replace with your work email password

    msg = MIMEText(message)
    msg['Subject'] = subject
    msg['From'] = sender_email
    msg['To'] = receiver_email

    with smtplib.SMTP_SSL('smtp.gmail.com', 465) as smtp:
        smtp.login(sender_email, password)
        smtp.send_message(msg)

# Function to perform response action
def perform_response():
    if not deauth_detected:
        subject = "No Deauthentication Packets Detected"
        message = "No deauthentication packets were detected within the specified timeframe."
        send_email(subject, message)
        print("Deauthentication Email Sent!")

# Start sniffing in a separate thread
sniff_thread = threading.Thread(target=sniff, kwargs={"iface": interface, "prn": info})
sniff_thread.start()

# Set a timer to perform response action if no deauth packet detected within 10 seconds
timer = threading.Timer(10.0, perform_response)
timer.start()
