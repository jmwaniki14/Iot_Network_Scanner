1. deauth attack
-->>notification scheduler for attacks after 2 min scan interval


2. DATA IMPORTATION AND EXPORTATION
sql database
mapping logic ====>>column A,B---static(attack type and simulation description 1,2,3)
dynamic data ====>>>result outputs(increment based on number of test simulations)

date of simulation

