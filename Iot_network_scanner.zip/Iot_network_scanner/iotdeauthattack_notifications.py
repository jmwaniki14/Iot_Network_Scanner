import threading
import smtplib
from email.mime.text import MIMEText
import schedule
import time
from scapy.all import *
from scapy.layers.dot11 import Dot11

# Set the network interface you want to monitor
interface = 'Wi-Fi'

# Set packet counter
packet_counter = 1

# Flag to track if deauthentication packet is detected
deauth_detected = False

# Extract information from the packet
def info(packet):
    global packet_counter
    global deauth_detected
    
    if packet.haslayer(Dot11):
        # The packet.subtype==12 statement indicates the deauth frame
        if packet.type == 0 and packet.subtype == 12:
            print(f"[+] Deauthentication Packet detected! Count: {packet_counter}")
            packet_counter += 1
            deauth_detected = True
            
    else:
        print("Non-Dot11 packet detected.")
        
# Define function to send email
def send_email(subject, message):
    sender_email = "jmwaniki14@gmail.com"  # Replace with your Gmail address
    receiver_email = "mwanikijust@gmail.com"  # Replace with the recipient's email address
    app_password = "xiey ovec jjui ugml"  # Replace with the generated app password

    msg = MIMEText(message)
    msg['Subject'] = subject
    msg['From'] = sender_email
    msg['To'] = receiver_email

    with smtplib.SMTP_SSL('smtp.gmail.com', 465) as smtp:
        smtp.login(sender_email, app_password)
        smtp.send_message(msg)

# Function to perform response action
def perform_response():
    global deauth_detected
    if not deauth_detected:
        subject = "No Deauthentication Packets Detected"
        message = "No deauthentication packets were detected within the specified timeframe."
    else:
        subject = "Deauthentication Attack Detected"
        message = "A deauthentication attack was detected!"
    send_email(subject, message)
    print("Email Sent!")
    # Reset deauth_detected flag
    deauth_detected = False

# Start sniffing in a separate thread
sniff_thread = threading.Thread(target=sniff, kwargs={"iface": interface, "prn": info})
sniff_thread.start()

# Schedule email sending every 2 minutes
schedule.every(2).minutes.do(perform_response)

# Infinite loop to run the scheduler
while True:
    schedule.run_pending()
    time.sleep(1)
