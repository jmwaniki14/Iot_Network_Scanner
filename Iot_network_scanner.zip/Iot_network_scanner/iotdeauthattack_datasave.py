from scapy.all import *
from scapy.layers.dot11 import Dot11
import threading
import smtplib
import mysql.connector
from email.mime.text import MIMEText
from datetime import datetime, timedelta

# Set the network interface you want to monitor
interface = 'Wi-Fi'

# Set packet counter
packet_counter = 1

# Flag to track if deauthentication packet is detected
deauth_detected = False

# MySQL database configuration
mysql_config = {
    'host': 'localhost', #replace with your server host name
    'user': 'justus', #replace with your database host username
    'password': 'Tumbleweed@14', #replace with your database host password
    'database': 'simulation_data' #replace with your database name
}

# Connect to MySQL database
try:
    mysql_conn = mysql.connector.connect(**mysql_config)
    mysql_cursor = mysql_conn.cursor()
except mysql.connector.Error as err:
    print(f"Error connecting to MySQL database: {err}")
    exit()

# Create table if not exists
create_table_query = """
CREATE TABLE IF NOT EXISTS deauth_attacks (
    id INT AUTO_INCREMENT PRIMARY KEY,
    timestamp DATETIME,
    detected BOOLEAN
)
"""
mysql_cursor.execute(create_table_query)
mysql_conn.commit()

# Extract information from the packet
def info(packet):
    global packet_counter
    global deauth_detected
    
    if packet.haslayer(Dot11):
        # The packet.subtype==12 statement indicates the deauth frame
        if packet.type == 0 and packet.subtype == 12:
            print(f"[+] Deauthentication Packet detected! Count: {packet_counter}")
            packet_counter += 1
            deauth_detected = True
            
    else:
        print("Non-Dot11 packet detected.")
        
# Define function to send email
def send_email(subject, message):
    sender_email = "jmwaniki14@gmail.com"  # Replace with your Gmail address
    receiver_email = "mwanikijust@gmail.com"  # Replace with the recipient's email address
    app_password = "xiey ovec jjui ugml"  # Replace with the generated app password

    msg = MIMEText(message)
    msg['Subject'] = subject
    msg['From'] = sender_email
    msg['To'] = receiver_email

    with smtplib.SMTP_SSL('smtp.gmail.com', 465) as smtp:
        smtp.login(sender_email, app_password)
        smtp.send_message(msg)

# Function to send email every minute
def send_periodic_email():
    while True:
        if deauth_detected:
            subject = "Deauthentication Attack Detected"
            message = "A deauthentication attack was detected."
            send_email(subject, message)
            print("Deauthentication Email Sent!")
        else:
            subject = "No Deauthentication Attack Detected"
            message = "No deauthentication attack was detected."
            send_email(subject, message)
            print("No Deauthentication Email Sent!")
        time.sleep(120)  # Send email every 2 minute

# Start sniffing in a separate thread
sniff_thread = threading.Thread(target=sniff, kwargs={"iface": interface, "prn": info})
sniff_thread.start()

# Start sending periodic email in a separate thread
email_thread = threading.Thread(target=send_periodic_email)
email_thread.start()

# Save output data to MySQL database
def save_to_database():
    while True:
        timestamp = datetime.now()
        detected = deauth_detected
        insert_query = "INSERT INTO deauth_attacks (timestamp, detected) VALUES (%s, %s)"
        mysql_cursor.execute(insert_query, (timestamp, detected))
        mysql_conn.commit()
        time.sleep(120)  # Save data every 2 minute

# Start saving data to database in a separate thread
db_thread = threading.Thread(target=save_to_database)
db_thread.start()
