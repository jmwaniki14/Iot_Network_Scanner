from scapy.arch.windows import get_windows_if_list

# Get the list of network interfaces
interfaces = get_windows_if_list()

# Print the list of interfaces
for interface in interfaces:
    print(interface)
